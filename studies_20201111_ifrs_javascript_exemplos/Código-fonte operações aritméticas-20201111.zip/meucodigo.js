var a = 12.3483574835;
var b = 3;
var c = a + b;
alert("Total da soma: " + c);

var nome;
nome = prompt("Informe o seu nome");
alert("Olá, " + nome);
