function submeti(){
  document.getElementById("log").innerHTML += "submeti<br>";
  return false;
}
function resetei(){
  document.getElementById("log").innerHTML += "resetei<br>";
}
function saiDoCampo(){
  document.getElementById("log").innerHTML += "sai do campo<br>";
}
function mudei(){
  document.getElementById("log").innerHTML += "mudei<br>";
}
function entreiNoCampo(){
  document.getElementById("log").innerHTML += "entrei no campo<br>";
}
function selecionei(){
  document.getElementById("log").innerHTML += "selecionei<br>";
}
function teclaBaixo(){
  document.getElementById("log").innerHTML += "tecla para baixo<br>";
}
function teclaCima(){
  document.getElementById("log").innerHTML += "tecla para cima<br>";
}