function carreguei(){
  document.getElementById("log").innerHTML += "carreguei<br>";
}
function redimensionei(){
  document.getElementById("log").innerHTML += "redimensionei<br>";
}