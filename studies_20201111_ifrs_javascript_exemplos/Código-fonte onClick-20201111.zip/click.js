function umClique(){
  document.getElementById("imagem").src="fachada.jpg";
  document.getElementById("log").innerHTML += "troca para a foto da fachada<br>";
}
function doisCliques(){
  document.getElementById("imagem").src="ifrs.gif";
  document.getElementById("log").innerHTML += "troca para o logo do IFRS-BG<br>";
}
