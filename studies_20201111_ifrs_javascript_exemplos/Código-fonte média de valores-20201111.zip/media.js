var nota1 = 4;
var nota2 = 7;
var nota3 = 5;
var media = (nota1+nota2+nota3)/3;
if(media >= 7){
  alert("Média: " + media +" - Aprovado");
}
else{
	alert("Média: " + media +" - Reprovado");
}
