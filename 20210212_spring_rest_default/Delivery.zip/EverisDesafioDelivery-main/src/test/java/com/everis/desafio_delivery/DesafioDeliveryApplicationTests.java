package com.everis.desafio_delivery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DesafioDeliveryApplicationTests {

	@Test
	void contextLoads() {
	}

}
