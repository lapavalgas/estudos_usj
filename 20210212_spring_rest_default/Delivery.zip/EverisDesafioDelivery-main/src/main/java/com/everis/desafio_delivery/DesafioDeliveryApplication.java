package com.everis.desafio_delivery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DesafioDeliveryApplication {

	public static void main(String[] args) {
		SpringApplication.run(DesafioDeliveryApplication.class, args);
	}

}
