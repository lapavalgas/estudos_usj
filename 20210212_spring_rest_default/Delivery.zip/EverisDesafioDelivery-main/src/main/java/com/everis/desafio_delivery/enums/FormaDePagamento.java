package com.everis.desafio_delivery.enums;


public enum FormaDePagamento {
	
	CREDITO,
	DEBITO,
	DINHEIRO;
}
