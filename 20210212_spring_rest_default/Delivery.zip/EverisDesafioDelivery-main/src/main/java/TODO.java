
public class TODO {
	
	/**
	 * TODO:
	 *  
	 * 2) Criar os Request e Response DTO
	 * 3) estoque [sugestão]
	 * 
	 * 
	 * 
	 * Apresentação 09/02/21
	 * 
	 * sistema para um restaurante/estabelecimento pequeno
	 * 
	 * produto: mercadoria no estoque
	 * item: mercadoria durante a compra
	 * 
	 * de início, cliente poderia ter 1 ou + contato -> fazer pedido desde enderecos vários
	 * 
	 * de início, pensei em evitar o uso de Dto's, mas na verdade Dto's evitariam
	 * o problema da recursividade ao se chamar objetos que comportam
	 * outros objetos
	 * 
	 * problema com cascade.PERSIST -> PERSIST parece não salvar dados ao lidar com 2 objetos
	 * ao mesmo tempo
	 */
	
	

}
